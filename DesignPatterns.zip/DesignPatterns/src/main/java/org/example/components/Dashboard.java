package org.example.components;

import org.example.utils.theme.ThemeManager;

import javax.swing.*;

public class Dashboard extends JPanel implements ThemeManager.ThemeChangeListener {
    @Override
    public void onThemeChange(boolean isDarkMode) {

    } // There was supposed to be more here
}
