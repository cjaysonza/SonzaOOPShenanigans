package org.example.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;

public class SidebarFactory {
    private static Color DEFAULT_BG = new Color(240, 240, 240 );
    private static Color HIGHLIGHTED = new Color(200, 200, 200 );

    public static JPanel createNavigationSidebar(int width, Consumer<String> onItemClicked) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setPreferredSize(new Dimension(width, Integer.MAX_VALUE));
        panel.setBackground(DEFAULT_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 1));

        return panel;
    }


    public static JPanel createCollapseableSidebar(
            int expandedWidth,
            int collapsedWidth,
            Consumer<String> onItemClicked) {
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(expandedWidth, Integer.MAX_VALUE));
        sidebar.setBackground(DEFAULT_BG);

        JButton toggleButton = new JButton("");
        toggleButton.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        toggleButton.setContentAreaFilled(false);
//        toggleButton.setForeground(DEFAULT_BG);
        toggleButton.setFocusPainted(false);

        JPanel navItemPanel = new JPanel();
        navItemPanel.setLayout(new BoxLayout(navItemPanel, BoxLayout.Y_AXIS));
        navItemPanel.setBorder(BorderFactory.createEmptyBorder(20,10, 20, 10));
        navItemPanel.setBackground(DEFAULT_BG);

        addNavigationItem(navItemPanel, "DASHBOARD", "⌚", onItemCLick);
        addNavigationItem(navItemPanel, "PROFILE", "🧑‍🏫", onItemCLick);
        addNavigationItem(navItemPanel, "ABOUT", "😀", onItemCLick);
        addNavigationItem(navItemPanel, "SETTINGS", "⚙️", onItemCLick);
        addNavigationItem(navItemPanel, "LOGOUT", "⬅️", onItemCLick);

        sidebar.add(toggleButton, BorderLayout.NORTH);
        sidebar.add(navItemPanel, BorderLayout.CENTER);

        toggleButton.addActionListener(e -> {
            boolean isCollapsed = sidebar.getWidth() == collapsedWidth;
            int newWidth = isCollapsed ? expandedWidth : collapsedWidth;
            sidebar.setPreferredSize(new Dimension(newWidth, Integer.MAX_VALUE));
            toggleButton.setText(isCollapsed? "📁" : "📁");

            sidebar.revalidate();
            sidebar.repaint();
        });

        return sidebar;
    }

    private static void addNavigationItem(JPanel panel, String text, String Icon, Consumer<String> onItemClicked) {
        JButton button = new JButton(text + " " + text);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMinimumSize(new Dimension(Integer.MAX_VALUE, 12));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        button.setFocusable(false);
        button.setContentAreaFilled(false);

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(HIGHLIGHTED);
                button.setOpaque(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(null);
                button.setOpaque(false);
            }
        });

        button.addActionListener(e -> {
            if(onItemClicked != null) {
                onItemClicked.accept(text);
            }
        });

        panel.add(button);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
    }
}
