package org.example.pages;

public class Landing {
}
