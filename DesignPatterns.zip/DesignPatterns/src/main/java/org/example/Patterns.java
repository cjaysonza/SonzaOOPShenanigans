package org.example;

public class Patterns {
    public static void Singleton() {
        // Creational Patterns
            // Singleton Patterns
                // -> databases
                // -> resources
                    // -> Load once to access
                // -> theme of your project (ex: turning the entire page/program to dark mode)



        // Structure Patterns

        // Behavioral Patterns


    }
}
