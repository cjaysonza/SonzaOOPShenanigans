package org.example.utils.theme;

import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;


public class ThemeManager {
    private static ThemeManager instance;
    private boolean isDarkMode = false; // good :)

    private Color lightBackground = Color.WHITE;
    private Color lightForeground = Color.BLACK;
    private Color lightComponent = new Color(0x40E0D0);

    private Color darkBackground = new Color(45, 45, 45);
    private Color darkForeground = Color.WHITE;
    private Color darkComponent = new Color(60, 60, 60);

    private final ArrayList<ThemeChangeListener> listeners = new ArrayList<>();

    public ThemeManager() {

    }

    public static ThemeManager getInstance() {
        if (instance == null) {
            instance = new ThemeManager();
        }
        return instance;
    }

    private void applyDarkTheme(Component comp) {
        comp.setForeground(darkForeground);
        if (comp instanceof JComponent jcomp) {
            if (jcomp instanceof JPanel || jcomp instanceof JLabel) {
                jcomp.setBackground(darkBackground);
            } else if (jcomp instanceof JButton || jcomp instanceof JTextField ||
                    jcomp instanceof JComboBox || jcomp instanceof JList) {
                jcomp.setBackground(darkBackground);
                jcomp.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 100)));
            }
        }
    }

    private void applyLightTheme(Component comp) {
        comp.setForeground(lightForeground);
        if (comp instanceof JComponent jcomp) {
            if (jcomp instanceof JPanel || jcomp instanceof JLabel) {
                jcomp.setBackground(lightBackground);
            } else if (jcomp instanceof JButton || jcomp instanceof JTextField ||
                    jcomp instanceof JComboBox || jcomp instanceof JList) {
                jcomp.setBackground(lightBackground);
                jcomp.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            }
        }
    }

    public boolean isDarkMode() {
        return isDarkMode;
    }

    public Color getBackgroundColor() {
        return isDarkMode ? darkBackground : lightBackground;
    }

    public Color getForegroundColor() {
        return isDarkMode ? darkBackground : lightBackground;
    }

    public Color getComponentColor() {
        return isDarkMode ? darkBackground : lightBackground;
    }



    public interface ThemeChangeListener {
        void onThemeChange(boolean isDarkMode);
    }

    public void addThemeChangeListener(ThemeChangeListener listener) {
        listeners.add(listener);
    }

    public void removeThemeChangeListener(ThemeChangeListener listener) {
        listeners.remove(listener);
    }

    public void toggleDarkMode() {
        isDarkMode = !isDarkMode;
        applyThemeToAllComponents();
        notifyListeners();
    }

    public void setDarkMode(boolean darkMode) {
        this.isDarkMode = darkMode;
        applyThemeToAllComponents();
        notifyListeners();
    }

    private void notifyListeners() {
        for(ThemeChangeListener listener : listeners) {
            listener.onThemeChange(isDarkMode);
        }
    }

    public void applyThemeToAllComponents() {
        for (Window window : Window.getWindows()) {
            applyThemeToContainer(window);
        }
    }

    public void applyThemeToContainer(Container container) {
        applyThemeToComponent(container);
        for (Component comp : container.getComponents()) {
            if (comp instanceof Container) {
                applyThemeToContainer((Container) comp);
            } else {
                applyThemeToComponent(comp);
            }
        }
    }

    private void applyThemeToComponent(Component comp) {
        if (isDarkMode) {
            applyDarkTheme(comp);
        } else {
            applyLightTheme(comp);
        }
    }
}
