package org.example.utils.theme;

import javax.swing.*;
import java.awt.*;

public class DarkModeToggle extends JPanel {
    private final JToggleButton toggleButton;

    public DarkModeToggle() {
        setLayout(new FlowLayout(FlowLayout.RIGHT));
        setOpaque(false);

        toggleButton = new JToggleButton();
        updateButtonAppearance();
        toggleButton.addActionListener(e -> {
            ThemeManager.getInstance().toggleDarkMode();
        });

        add(toggleButton);

    }

    private void updateButtonAppearance() {
        boolean isDarkMode = ThemeManager.getInstance().isDarkMode();
        if(isDarkMode) {
            toggleButton.setText("🌞 LIGHT MODE");
            toggleButton.setToolTipText("Switch to light mode.");
        } else {
            toggleButton.setText("🌙 NIGHT MODE");
            toggleButton.setToolTipText("Switch to dark mode.");
        }
        toggleButton.setBackground(ThemeManager.getInstance().getBackgroundColor());
        toggleButton.setForeground(ThemeManager.getInstance().getForegroundColor());
    }
}
